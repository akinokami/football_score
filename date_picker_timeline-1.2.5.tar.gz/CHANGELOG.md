## [1.2.5] - 17/06/2023

* Updated Intl

## [1.2.4] - 17/06/2023

* Updated Intl

## [1.2.3] - 06/03/2021

* Migrated to Null Safety

## [1.2.1] - 15/08/2020

* Added option to activate/deactivate certain dates
* Fixed bug where slider was going past the selected date

## [1.2.0] - 31/03/2020

* This version is breaking backward compatibility
* Added option to show past dates
* Added option to change the selected date text color separately
* Added a controller to the control the DatePicker widget
* Added option to change the width of the Date Widget Item

## [1.1.3] - 30/09/2019

* Fixed issue with Locale not being initialized

## [1.1.0] - 27/09/2019

* Added Locale option to show date in different language
* Added option to limit the number of date shown in the list
* Added option to manage width and height of the timeline

## [1.0.0] - 19/09/2019

* Added ability to manage text style for month, date and day text.
* Made changes to DatePickerTimeline constructor
* First Major release

## [0.0.3] - 13/09/2019

* Fixed bug where passing date to constructor was not working

## [0.0.2] - 05/09/2019

* Updated Readme 
* Added Selected Time Display to the Demo App
* Removed time from the selected date


## [0.0.1] - 24/08/2019

* Initial release.
